class Student
{
    String name;
    int rollno;
    int age;
    void display()
    {
        System.out.println("name:"+name);
        System.out.println("rollno:"+rollno);
        System.out.println("age:"+age);
        System.out.println();
    }
    public static void main(String args[])
    {
        Student s1=new Student();
        Student s2=new Student();
        s1.name="Likhitha";
        s1.rollno=23;
        s1.age=19;
        s2.name="Piya";
        s2.rollno=52;
        s2.age=19;
        s1.display();
        s2.display();
            }
}
        
